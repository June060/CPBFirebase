//
//  CollegeModel.swift
//  CPBFirebase
//
//  Created by James Howard on 11/6/23.
//

import Foundation

struct College{
    var name:String
    var url:String
    var location:String
    var numberOfStudents:Int
}
